<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package lorainccc_welded
 */

?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer">
		
		<div class="social2">
			<?php echo do_shortcode('[aps-social id="1"]')?>
		</div>
		<div class="row">
			<div class="large-6 columns">
		<div class="contactinfo">
			<h2>
				CONTACTS
			</h2>
			
			<h3>
				Interim Center Director
			</h3>
			<div class="address">
				<p>Michael Fox</p>
				<p>1005 North Abbe Road</p>
				<p>Elyria, OH 44035</p>
				<p>mfox@lorainccc.edu</p>
			</div>
			<div class="phone">
				<p>Phone: 866-529-WELD (9353)</p>
				<p>Direct: 440-366-4927</p>
				<p>Fax: 440-366-4624</p>
			</div>	
			<h3>
				Principal Investigator
			</h3>
			<div class="address">
				<p>Monica Pfarr</p>
				<p>1005 North Abbe Road</p>
				<p>Elyria, OH 44035</p>
				<p>mpfarr@aws.org</p>
			</div>
			<div class="phone">
				<p>Phone: 866-529-WELD (9353)</p>
				<p>Direct: 440-366-4927</p>
				<p>Fax: 440-366-4624</p>
			</div>
			<h3>
				Co-Principal Investigator
			</h3>
			<div class="address">
				<p>Dr. Rick Polanin</p>
				<p>1005 North Abbe Road</p>
				<p>Elyria, OH 44035</p>
				<p>rpolanin@mtco.com</p>
			</div>
			<div class="phone">
				<p>Phone: 866-529-WELD (9353)</p>
				<p>Direct: 440-366-4927</p>
				<p>Fax: 440-366-4624</p>
			</div>
		</div>
		

		</div>
			
		<div class="large-6 columns">
		<div class=quicklinks>
			<h2>Quick Links</h2>
			<a href="">Professional Development</a>
			<a href="">Become an Affiliate</a>
			<a href="">Scholarships</a>
			<a href="">Register for Training</a>
		</div>
		</div>
		</div>
		
	<div class="row">
		<div class="large-6 columns">
		
				<div class="copyright">
					<h3><i id="copyright" class="fa fa-copyright"></i> 2018 Weld-Ed.org</h3>
				</div>
		</div>
		<div class="large-6 columns">
				<nav id="site-navigation" class="main-navigation">
			<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false"><?php esc_html_e( 'Primary Menu', 'lorainccc_welded' ); ?></button>
			<?php
			wp_nav_menu( array(
				'theme_location' => 'menu-1',
				'menu_id'        => 'primary-menu',
			) );
			?>
		</nav>
		</div>
		
		</div>
	
			<div class="site-info">
				<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'lorainccc_welded' ) ); ?>">
					<?php
					/* translators: %s: CMS name, i.e. WordPress. */
					printf( esc_html__( 'Proudly powered by %s', 'lorainccc_welded' ), 'WordPress' );
					?>
				</a>
				<span class="sep"> | </span>
					<?php
					/* translators: 1: Theme name, 2: Theme author. */
					printf( esc_html__( 'Theme: %1$s by %2$s.', 'lorainccc_welded' ), 'lorainccc_welded', '<a href="http://underscores.me/">Underscores.me</a>' );
					?>
			</div><!-- .site-info -->
		
		
			

	
		
	<!--	<div class="sitemap">
			<p>| site map</p>
		</div>-->
		
	</div>	
		
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>

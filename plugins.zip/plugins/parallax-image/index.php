<?php

// quack

[![Codeship Status](https://app.codeship.com/projects/e616fbf0-13cd-0135-911a-3e3c5a78d2e0/status?branch=master)](https://codeship.com/projects/215186)

### Supported by BrowserStack
Thanks to [BrowserStack](https://browserstack.com/) for their support of this open-source project.

<img src="https://responsive.menu/wp-content/themes/responsive-menu/imgs/browserstacklogo.svg" width="150">
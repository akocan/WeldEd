<?php 
namespace MaxButtons;
defined('ABSPATH') or die('No direct access permitted');

$collectionClass["basic"] = "basicCollection"; 

class basicCollection extends maxCollection
{



}

?>

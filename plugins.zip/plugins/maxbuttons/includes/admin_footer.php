<?php namespace MaxButtons; ?>
 
	</div> <!-- main --> 
	
	<?php do_action("mb-interface-end");  ?>
</div><!-- #maxbuttons --> 

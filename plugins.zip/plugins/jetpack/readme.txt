=== Jetpack by WordPress.com ===
Contributors: automattic, adamkheckler, aduth, akirk, allendav, alternatekev, andy, annezazu, apeatling, azaozz, batmoo, barry, beaulebens, blobaugh, cainm, cena, cfinke, chaselivingston, chellycat, clickysteve, csonnek, danielbachhuber, davoraltman, daniloercoli, designsimply, dllh, drawmyface, dsmart, dzver, ebinnion, eliorivero, enej, eoigal, erania-pinnera, ethitter, gcorne, georgestephanis, gibrown, goldsounds, hew, hugobaeta, hypertextranch, iammattthomas, iandunn, jblz, jeherve, jenhooks, jenia, jgs, jkudish, jmdodd, Joen, johnjamesjacoby, jshreve, koke, kraftbj, lancewillett, lschuyler, macmanx, martinremy, matt, matveb, mattwiebe, maverick3x6, mcsf, mdawaffe, michael-arestad, migueluy, mikeyarce, mkaz, nancythanki, nickmomrik, obenland, oskosk, pento, professor44, rachelsquirrel, rdcoll, ryancowles, richardmuscat, richardmtl, roccotripaldi, samhotchkiss, scarstocea, sdquirk, stephdau, tmoorewp, tyxla, Viper007Bond, westi, yoavf, zinigor
Tags: Jetpack, WordPress.com, backup, security, related posts, CDN, speed, anti-spam, social sharing, SEO, video, stats
Stable tag: 6.1
Requires at least: 4.7
Tested up to: 4.9

The ideal plugin for stats, related posts, search engine optimization, social sharing, protection, backups, security, and more.

== Description ==

Hassle-free design, marketing, and security — all in one place.

= Design Services =
Create and customize your WordPress site from start to finish. Jetpack helps you with:

* Hundreds of professional themes for any kind of site
* Intuitive and powerful customization tools
* Unlimited and high-speed image and video content delivery network
* Lazy image loading for a faster mobile experience
* Integration with the official WordPress mobile apps

= Marketing Services =
Measure, promote, and earn moment from your site. Jetpack helps you with:

* Site stats and analytics
* Automated social media posting and scheduling in advance
* Elasticsearch-powered related content and site search
* SEO tools for Google, Bing, Twitter, Facebook, and WordPress.com
* Advertising program that includes the best of AdSense, Facebook Ads, AOL, Amazon, Google AdX, and Yahoo
* Simple PayPal payment buttons

= Security Services =
Stop worrying about data loss, downtime, and hacking. Jetpack helps you with:

* Brute force attack protection, spam filtering, and downtime monitoring
* Daily or real-time backups of your entire site
* Secure logins with optional two-factor authentication
* Malware scanning, code scanning, and automated threat resolution
* Fast, priority support from WordPress experts

= Expert Support =
We have a global team of Happiness Engineers ready to help you. Ask your questions in the support forum, or [contact us directly](https://jetpack.com/contact-support).

= Paid Services =
Compare our [simple and affordable plans](https://jetpack.com/pricing?from=wporg) or take a [product tour](https://jetpack.com/features?from=wporg) to learn more.

= Get Started =
Installation is free, quick, and easy. [Install Jetpack from our site](https://jetpack.com/install?from=wporg) in minutes.

== Installation ==

= Automated Installation =
Installation is free, quick, and easy. [Install Jetpack from our site](https://jetpack.com/install?from=wporg) in minutes.

= Manual Alternatives =
Alternatively, install Jetpack via the plugin directory, or upload the files manually to your server and follow the on-screen instructions. If you need additional help [read our detailed instructions](https://jetpack.com/support/installing-jetpack/).

== Frequently Asked Questions ==

= Is Jetpack free? =
Yes! Jetpack's core features are and always will be free.

These include: [site stats](https://jetpack.com/features/traffic/site-stats), a [high-speed CDN](https://jetpack.com/features/writing/content-delivery-network/) for images, [related posts](https://jetpack.com/features/traffic/related-posts), [downtime monitoring](https://jetpack.com/features/security/downtime-monitoring), brute force [attack protection](https://jetpack.com/features/security/brute-force-attack-protection), [automated sharing](https://jetpack.com/features/traffic/automatic-publishing/) to social networks, [sidebar customization](https://jetpack.com/features/writing/sidebar-customization/), and many more.

= Should I purchase a paid plan? =
Jetpack's paid services include real-time backups, security scanning, premium themes, spam filtering, video hosting, site monetization, SEO tools, search, priority support, and more.

To learn more about the essential security and WordPress services we provide, visit our [plan comparison page](https://jetpack.com/pricing?from=wporg).

= Why do I need a WordPress.com account? =

Since Jetpack and its services are provided and hosted by WordPress.com, a WordPress.com account is required for Jetpack to function.

= I already have a WordPress account, but Jetpack isn't working. What's going on? =

A WordPress.com account is different from the account you use to log into your self-hosted WordPress. If you can log into [WordPress.com](https://wordpress.com), then you already have a WordPress.com account. If you can't, you can easily create one [during installation](https://jetpack.com/install?from=wporg).

= How do I view my stats? =

Once you've installed Jetpack your stats will be available on [WordPress.com/Stats](https://wordpress.com/stats), on the official [WordPress mobile apps](https://apps.wordpress.com/mobile/), and on your Jetpack dashboard.

= How do I contribute to Jetpack? =

There are opportunities for developers at all levels to contribute. [Learn more about contributing to Jetpack](https://jetpack.com/contribute) or consider [joining our beta program](https://jetpack.com/beta).


== Screenshots ==

1. Dashboard: Bird’s eye view of your site stats, status, and health.
2. Safety: Protect your site and data with powerful security services.
3. Engagement: Social sharing, likes, and related posts.
4. Analytics: Actionable site stats and traffic insights.
5. Traffic: SEO Tools for Google, Twitter, Facebook and more.

== Changelog ==

= 6.1 =

* Release date: May 1, 2018
* Release post: https://wp.me/p1moTy-7Sj

**Major Enhancements**

* WordAds: Introduced shortcode for inline Ad placement.
* WordAds: Added support for the ads.txt file.

**Enhancements**

* Dashboard: We improved the styles of status numbers so it doesn't look like floating.
* JSON API: Added support for Google My Business integration available on WordPress.com.
* Masterbar: We removed the Next Steps link from the Account sidebar.
* Publicize: Let the user know that we are going to send emails to subscribers and publicize to the different accounts.
* Settings: Added  "Privacy Information" links to each Jetpack module/feature card.
* Shortcodes: Mixcloud shortcode now uses oEmbed.
* Stats: Added a new filter jetpack_honor_dnt_header_for_stats, which if enabled would not track stats for visitors with DNT enabled.
* Sync: Removed requirement for gzencode.
* Widgets: always load script via HTTPS for Gravatar Hovercards.

**Improved compatibility**

* Social Icons Widget: Improved support on screen reader text for themes that do not provide support out of the box.
* Sharing: Removed the sharing and like display functionality from Cart, Checkout, and Account WooCommerce pages.

**Bug fixes**

* Admin Page: We fixed the internationalization of the plans page.
* Ads: We fixed a problem that impeded Premium Plan customers to activate Google Analytics.
* Auto Updates: We fixed a warning being thrown due to a bad concatenation of strings.
* General: Fixed a warning that was being logged due to attempting to use in_array() over a variable that didn't always contain an array.
* General: Fixed Warning: count(): Parameter must be an array or an object that implements Countable showing on PHP 7.x.
* JSON API: Fixed internationalization on embed endpoint.
* Theme Tools: Show featured images in WooCommerce pages when Display on blog and archives is turned off for Themes that support this feature.
* Publicize: Avoid adding Publicize post meta when a post transitions to publish and it is not a publicize-able post type.
* Settings: Fixed the icon representing the minimum plan needed for SEO and Google Analytics features.
* Slideshow: Fixed an invalid argument supplied for foreach() warning.
* SSO: We fixed the name of a filter which contained a typo before. The filter is now named: `jetpack_sso_auth_cookie_expiration`.
* SSO: Fixed some cases where we were not handling secure cookies for sites running over https.
* Sync: Fixed Warning: Invalid argument supplied for foreach().
* Sync: Fixed Warning: Warning: json_encode(): recursion detected.
* WooCommerce Analytics: fixed broken Remove From Cart link.

